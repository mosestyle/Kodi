# script.keymap
A keymap editor for Kodi
